import socket
import datetime
from PermisDeConducere import PermisDeConducere

class PDCManager(object):
    pdcs = []
    categories = []
    
    def __init__(self):
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connection.connect((socket.gethostbyaddr('0.0.0.0')[0], 30000))
        self.connection.sendall(b"GET /drivers-licenses/list?length=150\r\n\r\n")
        intermStr = ""
        binAry = b'1'
        while(binAry != b''):
            binAry = self.connection.recv(1024)
            intermStr = "" + intermStr + binAry.decode()
        self.mkPDCArray(intermStr)
        
    def mkPDCArray(self, intermStr):
        intermStr = intermStr[1 : len(intermStr)-1]
        intermStrs = intermStr.split("},{", 149);
        if len(intermStrs) > 1:
            for i in range(0,len(intermStrs)):
                if i > 0:
                    intermStrs[i] = "{" + intermStrs[i]
                if i < len(intermStrs) - 1:
                    intermStrs[i] = "{0}{1}".format(intermStrs[i], "}")
        for j in intermStrs:
            newPDC = PermisDeConducere()
            newPDC.constructorL(j)
            self.pdcs.append(newPDC)
        self.runUI()

    def runUI(self):
        print("What would you like to do?")
        print("     - List all licenses (write '0') ")
        print("     - List suspended licenses by the authority (write '1') ")
        print("     - Extract valid licenses issued until today's date (write '2') ")
        print("     - Find licenses based on category and their count (write '3') ")
        print("     - Exit (write 'X' or 'x') ")
        print("Your input:")
        operation = input()
        if((operation == 'X') or (operation == 'x')):
            print("Bye!")
            return
        if(operation == '0'):
            self.doList()
        elif(operation == '1'):
            self.doSuspended()
        elif(operation == '2'):
            self.doValid()
        elif(operation == '3'):
            self.doCat()
        else:
            print("Wrong input")
        self.runUI()

    def doList(self):
        print("Permise suspendate:")
        for pdc in self.pdcs:
            if(pdc.suspendat):
                print("     Permis nr. {0}, categoria {1}, detinut de {2} {3}, valabil intre {4} si {5} suspendat".format(pdc.id, pdc.categorie, pdc.nume, pdc.prenume, pdc.data_de_emitere, pdc.data_de_expirare))
            else:
                print("     Permis nr. {0}, categoria {1}, detinut de {2} {3}, valabil intre {4} si {5}".format(pdc.id, pdc.categorie, pdc.nume, pdc.prenume, pdc.data_de_emitere, pdc.data_de_expirare))

    def doSuspended(self):
        print("Permise suspendate:")
        for pdc in self.pdcs:
            if(pdc.suspendat):
                print("     Permis nr. {0}, categoria {1}, detinut de {2} {3}, valabil intre {4} si {5}".format(pdc.id, pdc.categorie, pdc.nume, pdc.prenume, pdc.data_de_emitere, pdc.data_de_expirare))

    def doValid(self):
        print("Permise valide:")
        currentDate = datetime.datetime.now();
        for pdc in self.pdcs:
            dela = datetime.datetime.strptime(pdc.data_de_emitere, '%d/%m/%Y')
            panala = datetime.datetime.strptime(pdc.data_de_expirare, '%d/%m/%Y')
            if((panala > currentDate) and (pdc.suspendat == False)):
                print("     Permis nr. {0}, categoria {1}, detinut de {2} {3}, valabil intre {4} si {5}".format(pdc.id, pdc.categorie, pdc.nume, pdc.prenume, pdc.data_de_emitere, pdc.data_de_expirare))

    def doCat(self):
        print("Categorii:")
        if(len(self.categories) == 0):
            self.mkCategories()
        for cat in self.categories:
            print("Cat. {0}: {1}".format(cat[0], cat[1])) 

    def mkCategories(self):
        auxCats = []
        auxCatNrs = []
        for pdc in self.pdcs:
            if(pdc.categorie not in auxCats):
                auxCats.append(pdc.categorie)
                auxCatNrs.append(1)
            else:
                index = auxCats.index(pdc.categorie)
                auxCatNrs[index] = auxCatNrs[index] + 1
        self.categories = list(zip(auxCats, auxCatNrs))
        self.categories.sort(key = self.auxCatFunction)

    def auxCatFunction(self, val):
        return(val[0])
