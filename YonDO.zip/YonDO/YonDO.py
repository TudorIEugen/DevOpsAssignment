from PermisDeConducere import PermisDeConducere
from PDCManager import PDCManager

pdcm = PDCManager()
