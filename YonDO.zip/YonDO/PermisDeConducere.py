from tokenize import String
import json


class PermisDeConducere(object):
    id = 0
    nume = ""
    prenume = ""
    categorie = ""
    data_de_emitere = ""
    data_de_expirare = ""
    suspendat = True
    def __init__(self):
        self.id = 0
        self.nume = ""
        self.prenume = ""
        self.categorie = ""
        self.data_de_emitere = ""
        self.data_de_expirare = ""
        self.suspendat = True
    def constructorP(self, id, nume, prenume, categorie, data_de_emitere, data_de_expirare, suspendat):
        self.id = id
        self.nume = nume
        self.prenume = prenume
        self.categorie = categorie
        self.data_de_emitere = data_de_emitere
        self.data_de_expirare = data_de_expirare
        self.suspendat = suspendat
    def constructorC(self, permis1):
        if(isinstance(permis1, PermisDeConducere)):
            self.constructorP(permis1.id, permis1.nume, permis1.prenume, permis1.categorie, permis1.data_de_emitere, permis1.data_de_expirare, permis1.suspendat)
    def constructorL(self, line):
        jsonO = json.loads(line)
        self.constructorP(jsonO["id"], jsonO["nume"], jsonO["prenume"], jsonO["categorie"], jsonO["dataDeEmitere"], jsonO["dataDeExpirare"], jsonO["suspendat"])        
        
        #params = line.split(",")
        #if(len(params) < 7):
        #    self.__init__()
        #    return
        #for param in params:
        #    param.replace("\"","")
        #self.constructorP(int(params[0]), params[1], params[2], params[3], params[4], params[5], bool(params[6]))
        



